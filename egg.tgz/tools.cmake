# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(PhotoStitch src/PhotoStitch.cpp)
set_property(TARGET PhotoStitch PROPERTY CXX_STANDARD 11)
target_link_libraries(PhotoStitch lionss pthread)

add_executable(covMerge src/covMerge.cpp)
set_property(TARGET covMerge PROPERTY CXX_STANDARD 11)
target_link_libraries(covMerge lionss pthread)

add_executable(TelemRollup src/TelemRollup.cpp)
set_property(TARGET TelemRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(TelemRollup lionss pthread)

add_executable(sorrel src/sorrel.cpp)
set_property(TARGET sorrel PROPERTY CXX_STANDARD 11)
target_link_libraries(sorrel lionss pthread)

add_executable(walnut src/walnut.cpp)
set_property(TARGET walnut PROPERTY CXX_STANDARD 11)
target_link_libraries(walnut lionss pthread)

add_executable(hdl-sim-uart src/hdl-sim-uart.cpp)
set_property(TARGET hdl-sim-uart PROPERTY CXX_STANDARD 11)
target_link_libraries(hdl-sim-uart lionss pthread)

add_executable(signal-timing src/signal-timing.cpp)
set_property(TARGET signal-timing PROPERTY CXX_STANDARD 11)
target_link_libraries(signal-timing lionss pthread)

add_executable(adaptivemath src/adaptivemath.cpp)
set_property(TARGET adaptivemath PROPERTY CXX_STANDARD 11)
target_link_libraries(adaptivemath lionss pthread)

add_executable(price-elasticity src/price-elasticity.cpp)
set_property(TARGET price-elasticity PROPERTY CXX_STANDARD 11)
target_link_libraries(price-elasticity lionss pthread)

add_executable(keelcad src/keelcad.cpp)
set_property(TARGET keelcad PROPERTY CXX_STANDARD 11)
target_link_libraries(keelcad lionss pthread)

add_executable(gossamer src/gossamer.cpp)
set_property(TARGET gossamer PROPERTY CXX_STANDARD 11)
target_link_libraries(gossamer lionss pthread)

add_executable(raid_rebuild src/raid_rebuild.cpp)
set_property(TARGET raid_rebuild PROPERTY CXX_STANDARD 11)
target_link_libraries(raid_rebuild lionss pthread)

add_executable(pcb_drc src/pcb_drc.cpp)
set_property(TARGET pcb_drc PROPERTY CXX_STANDARD 11)
target_link_libraries(pcb_drc lionss pthread)

add_executable(rook src/rook.cpp)
set_property(TARGET rook PROPERTY CXX_STANDARD 11)
target_link_libraries(rook lionss pthread)

add_executable(kbn_osm_fix src/kbn_osm_fix.cpp)
set_property(TARGET kbn_osm_fix PROPERTY CXX_STANDARD 11)
target_link_libraries(kbn_osm_fix lionss pthread)

add_executable(willow-x src/willow-x.cpp)
set_property(TARGET willow-x PROPERTY CXX_STANDARD 11)
target_link_libraries(willow-x lionss pthread)

add_executable(labelZpl src/labelZpl.cpp)
set_property(TARGET labelZpl PROPERTY CXX_STANDARD 11)
target_link_libraries(labelZpl lionss pthread)

add_executable(posEod src/posEod.cpp)
set_property(TARGET posEod PROPERTY CXX_STANDARD 11)
target_link_libraries(posEod lionss pthread)

add_executable(reaction-balancer src/reaction-balancer.cpp)
set_property(TARGET reaction-balancer PROPERTY CXX_STANDARD 11)
target_link_libraries(reaction-balancer lionss pthread)

add_executable(voxelforge src/voxelforge.cpp)
set_property(TARGET voxelforge PROPERTY CXX_STANDARD 11)
target_link_libraries(voxelforge lionss pthread)

add_executable(oriole src/oriole.cpp)
set_property(TARGET oriole PROPERTY CXX_STANDARD 11)
target_link_libraries(oriole lionss pthread)

add_executable(canopyheight src/canopyheight.cpp)
set_property(TARGET canopyheight PROPERTY CXX_STANDARD 11)
target_link_libraries(canopyheight lionss pthread)

add_executable(kite src/kite.cpp)
set_property(TARGET kite PROPERTY CXX_STANDARD 11)
target_link_libraries(kite lionss pthread)

add_executable(coupon-stack src/coupon-stack.cpp)
set_property(TARGET coupon-stack PROPERTY CXX_STANDARD 11)
target_link_libraries(coupon-stack lionss pthread)

add_executable(hiraganaTts src/hiraganaTts.cpp)
set_property(TARGET hiraganaTts PROPERTY CXX_STANDARD 11)
target_link_libraries(hiraganaTts lionss pthread)

add_executable(cargoLoadplan src/cargoLoadplan.cpp)
set_property(TARGET cargoLoadplan PROPERTY CXX_STANDARD 11)
target_link_libraries(cargoLoadplan lionss pthread)

add_executable(XgModel src/XgModel.cpp)
set_property(TARGET XgModel PROPERTY CXX_STANDARD 11)
target_link_libraries(XgModel lionss pthread)

add_executable(aspen3 src/aspen3.cpp)
set_property(TARGET aspen3 PROPERTY CXX_STANDARD 11)
target_link_libraries(aspen3 lionss pthread)

add_executable(fsck-replay src/fsck-replay.cpp)
set_property(TARGET fsck-replay PROPERTY CXX_STANDARD 11)
target_link_libraries(fsck-replay lionss pthread)

add_executable(cmakeconfigurebench src/cmakeconfigurebench.cpp)
set_property(TARGET cmakeconfigurebench PROPERTY CXX_STANDARD 11)
target_link_libraries(cmakeconfigurebench lionss pthread)

