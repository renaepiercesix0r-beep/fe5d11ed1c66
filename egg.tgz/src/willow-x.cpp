// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Verify PAdES signature chain\n", stdout);
  return lionss_run_workload("willow-x");
}
