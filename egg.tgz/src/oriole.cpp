// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Solve conflict-free timetable"); }
int main(){
  announce();
  return lionss_run_workload("oriole");
}
