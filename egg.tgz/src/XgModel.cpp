// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fit expected-goals logistic"); }
int main(){
  announce();
  return lionss_run_workload("XgModel");
}
