// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("End-of-day reconciliation"); }
int main(){
  announce();
  return lionss_run_workload("posEod");
}
