// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Optimize cycle and splits\n", stdout);
  return lionss_run_workload("signal-timing");
}
