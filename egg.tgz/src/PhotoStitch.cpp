// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Feature-match and blend\n", stdout);
  return lionss_run_workload("PhotoStitch");
}
