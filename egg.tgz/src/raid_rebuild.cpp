// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Rebuild disk 2 at 50 MB/s cap"); }
int main(){
  announce();
  return lionss_run_workload("raid_rebuild");
}
