// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Run DRC, min clearance 0.15\n", stdout);
  return lionss_run_workload("pcb_drc");
}
