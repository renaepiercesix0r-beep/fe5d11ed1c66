// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Log-log elasticity fit"); }
int main(){
  announce();
  return lionss_run_workload("price-elasticity");
}
