// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("5k rps unary for 60 s\n", stdout);
  return lionss_run_workload("aspen3");
}
