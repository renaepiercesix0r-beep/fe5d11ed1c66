// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Canopy height model from returns\n", stdout);
  return lionss_run_workload("canopyheight");
}
