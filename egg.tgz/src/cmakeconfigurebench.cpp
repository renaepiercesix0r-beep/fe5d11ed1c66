// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Time 20 configure runs"); }
int main(){
  announce();
  return lionss_run_workload("cmakeconfigurebench");
}
