// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Simulate 256 bytes at 115200"); }
int main(){
  announce();
  return lionss_run_workload("hdl-sim-uart");
}
