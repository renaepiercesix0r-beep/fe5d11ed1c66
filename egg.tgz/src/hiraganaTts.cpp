// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Synthesize waveform\n", stdout);
  return lionss_run_workload("hiraganaTts");
}
