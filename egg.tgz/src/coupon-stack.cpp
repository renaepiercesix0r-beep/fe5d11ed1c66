// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Best legal stacking order"); }
int main(){
  announce();
  return lionss_run_workload("coupon-stack");
}
