// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Render ZPL to PNG at 203 dpi");
  std::fflush(stdout);
  return lionss_run_workload("labelZpl");
}
